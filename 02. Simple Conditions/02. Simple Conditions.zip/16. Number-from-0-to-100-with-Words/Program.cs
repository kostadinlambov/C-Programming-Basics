﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Number_0_100_to_Text
{
    class Program
    {
        static void Main(string[] args)
        {
            double numberInput = double.Parse(Console.ReadLine());

            if (numberInput >= 0 && numberInput <= 100)
            {
                string number = Convert.ToString(numberInput);

                if (number == "0")
                    Console.WriteLine("zero");
                else if (number == "1")
                    Console.WriteLine("one");
                else if (number == "2")
                    Console.WriteLine("two");
                else if (number == "3")
                    Console.WriteLine("three");
                else if (number == "4")
                    Console.WriteLine("four");
                else if (number == "6")
                    Console.WriteLine("six");
                else if (number == "7")
                    Console.WriteLine("seven");
                else if (number == "8")
                    Console.WriteLine("eight");
                else if (number == "9")
                    Console.WriteLine("nine");
                else if (number == "10")
                    Console.WriteLine("ten");
                else if (number == "11")
                    Console.WriteLine("eleven");
                else if (number == "12")
                    Console.WriteLine("twelve");
                else if (number == "13")
                    Console.WriteLine("thirteen");
                else if (number == "14")
                    Console.WriteLine("fourteen");
                else if (number == "15")
                    Console.WriteLine("fifteen");
                else if (number == "16")
                    Console.WriteLine("sixteen");
                else if (number == "17")
                    Console.WriteLine("seventeen");
                else if (number == "18")
                    Console.WriteLine("eighteen");
                else if (number == "19")
                    Console.WriteLine("nineteen");
                else if (number == "20")
                    Console.WriteLine("twenty");
                else if (number == "21")
                    Console.WriteLine("twenty " + "one");
                else if (number == "22")
                    Console.WriteLine("twenty " + "two");
                else if (number == "23")
                    Console.WriteLine("twenty " + "three");
                else if (number == "24")
                    Console.WriteLine("twenty " + "four");
                else if (number == "25")
                    Console.WriteLine("twenty " + "five");
                else if (number == "26")
                    Console.WriteLine("twenty " + "six");
                else if (number == "27")
                    Console.WriteLine("twenty " + "seven");
                else if (number == "28")
                    Console.WriteLine("twenty " + "eight");
                else if (number == "29")
                    Console.WriteLine("twenty " + "nine");
                else if (number == "30")
                    Console.WriteLine("thirty");
                else if (number == "31")
                    Console.WriteLine("thirty " + "one");
                else if (number == "32")
                    Console.WriteLine("thirty " + "two");
                else if (number == "33")
                    Console.WriteLine("thirty " + "three");
                else if (number == "34")
                    Console.WriteLine("thirty " + "four");
                else if (number == "35")
                    Console.WriteLine("thirty " + "five");
                else if (number == "36")
                    Console.WriteLine("thirty " + "six");
                else if (number == "37")
                    Console.WriteLine("thirty " + "seven");
                else if (number == "38")
                    Console.WriteLine("thirty " + "eight");
                else if (number == "39")
                    Console.WriteLine("thirty " + "nine");
                else if (number == "40")
                    Console.WriteLine("forty");
                else if (number == "41")
                    Console.WriteLine("forty " + "one");
                else if (number == "42")
                    Console.WriteLine("forty " + "two");
                else if (number == "43")
                    Console.WriteLine("forty " + "three");
                else if (number == "44")
                    Console.WriteLine("forty " + "four");
                else if (number == "45")
                    Console.WriteLine("forty " + "five");
                else if (number == "46")
                    Console.WriteLine("forty " + "six");
                else if (number == "47")
                    Console.WriteLine("forty " + "seven");
                else if (number == "48")
                    Console.WriteLine("forty " + "eight");
                else if (number == "49")
                    Console.WriteLine("forty " + "nine");
                else if (number == "50")
                    Console.WriteLine("fifty");
                else if (number == "51")
                    Console.WriteLine("fifty " + "one");
                else if (number == "52")
                    Console.WriteLine("fifty " + "two");
                else if (number == "53")
                    Console.WriteLine("fifty " + "three");
                else if (number == "54")
                    Console.WriteLine("fifty " + "four");
                else if (number == "55")
                    Console.WriteLine("fifty " + "five");
                else if (number == "56")
                    Console.WriteLine("fifty " + "six");
                else if (number == "57")
                    Console.WriteLine("fifty " + "seven");
                else if (number == "58")
                    Console.WriteLine("fifty " + "eight");
                else if (number == "59")
                    Console.WriteLine("fifty " + "nine");
                else if (number == "60")
                    Console.WriteLine("sixty");
                else if (number == "61")
                    Console.WriteLine("sixty " + "one");
                else if (number == "62")
                    Console.WriteLine("sixty " + "two");
                else if (number == "63")
                    Console.WriteLine("sixty " + "three");
                else if (number == "64")
                    Console.WriteLine("sixty " + "four");
                else if (number == "65")
                    Console.WriteLine("sixty " + "five");
                else if (number == "66")
                    Console.WriteLine("sixty " + "six");
                else if (number == "67")
                    Console.WriteLine("sixty " + "seven");
                else if (number == "68")
                    Console.WriteLine("sixty " + "eight");
                else if (number == "69")
                    Console.WriteLine("fifty " + "nine");
                else if (number == "70")
                    Console.WriteLine("seventy");
                else if (number == "71")
                    Console.WriteLine("seventy " + "one");
                else if (number == "72")
                    Console.WriteLine("seventy " + "two");
                else if (number == "73")
                    Console.WriteLine("seventy " + "three");
                else if (number == "74")
                    Console.WriteLine("seventy " + "four");
                else if (number == "75")
                    Console.WriteLine("seventy " + "five");
                else if (number == "76")
                    Console.WriteLine("seventy " + "six");
                else if (number == "77")
                    Console.WriteLine("seventy " + "seven");
                else if (number == "78")
                    Console.WriteLine("seventy " + "eight");
                else if (number == "79")
                    Console.WriteLine("seventy " + "nine");
                else if (number == "80")
                    Console.WriteLine("eighty");
                else if (number == "81")
                    Console.WriteLine("eighty " + "one");
                else if (number == "82")
                    Console.WriteLine("eighty " + "two");
                else if (number == "83")
                    Console.WriteLine("eighty " + "three");
                else if (number == "84")
                    Console.WriteLine("eighty " + "four");
                else if (number == "85")
                    Console.WriteLine("eighty " + "five");
                else if (number == "86")
                    Console.WriteLine("eighty " + "six");
                else if (number == "87")
                    Console.WriteLine("eighty " + "seven");
                else if (number == "88")
                    Console.WriteLine("eighty " + "eight");
                else if (number == "89")
                    Console.WriteLine("eighty " + "nine");
                else if (number == "90")
                    Console.WriteLine("ninety");
                else if (number == "91")
                    Console.WriteLine("ninety " + "one");
                else if (number == "92")
                    Console.WriteLine("ninety " + "two");
                else if (number == "93")
                    Console.WriteLine("ninety " + "three");
                else if (number == "94")
                    Console.WriteLine("ninety " + "four");
                else if (number == "95")
                    Console.WriteLine("ninety " + "five");
                else if (number == "96")
                    Console.WriteLine("ninety " + "six");
                else if (number == "97")
                    Console.WriteLine("ninety " + "seven");
                else if (number == "98")
                    Console.WriteLine("ninety " + "eight");
                else if (number == "99")
                    Console.WriteLine("ninety " + "nine");
                else if (number == "100")
                    Console.WriteLine("one hundred");
            }
            else
                Console.WriteLine("Invalid number");
        }
    }
}
